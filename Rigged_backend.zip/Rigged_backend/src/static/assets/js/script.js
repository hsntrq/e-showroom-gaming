var user = "HasanNaseem";
var pwd = "123456789";
var loggedin = 0;
var rem = 0;
var rem_u;
var rem_p;